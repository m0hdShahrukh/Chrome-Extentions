(() => {
  "use strict";

  if (window.__TYPOGRAPHY_LAB_V3__) return;
  window.__TYPOGRAPHY_LAB_V3__ = true;

  const RUNTIME_STYLE_ID = "typology-lab-runtime-style";
  const PICKER_STYLE_ID = "typology-lab-picker-style";
  const TEXT_MARK = "data-typolab-text";
  const ROOT_MARK = "data-typolab-root";
  const EXCLUDE_MARK = "data-typolab-exclude";
  const HOVER_ID = "typography-lab-hover-highlight";
  const SELECTED_ID = "typography-lab-selected-highlight";

  let pickerActive = false;
  let pickerHover = null;
  let selectedElement = null;
  let observer = null;
  let reapplyTimer = null;
  let lastState = null;
  let lastInfo = null;

  // Actual FontFace instances registered by Typography Lab.
  // This avoids relying only on target-page @import/CSS URL loading,
  // which can be affected by page CSP/CORS.
  const loadedGoogleFontFaces = new Map();
  const loadedCustomFontFaces = new Map();

  const EXCLUDED_TAGS = new Set([
    "script", "style", "noscript", "template", "svg", "path", "canvas",
    "video", "audio", "iframe", "object", "embed", "option", "textarea"
  ]);

  const ICON_CLASS_PATTERN = /(^|[-_\s])(icon|icons|material-icons?|material-symbols?|fa|fas|far|fab|fad|ph|lucide|dashicons|glyph|symbol|chevron|caret|arrow|hamburger|search-icon|close-icon|menu-icon)([-_\s]|$)/i;

  const normalizeState = (state = {}) => ({
    enabled: true,
    target: "site",
    selector: "",
    preserveIcons: true,
    fontFamily: "Inter",
    fontStack: "\"Inter\", system-ui, -apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif",
    fontFamilyMode: "override",
    fontSize: 16,
    fontWeight: 400,
    lineHeight: 1.6,
    letterSpacing: 0,
    wordSpacing: 0,
    textTransform: "none",
    fontStyle: "normal",
    textDecoration: "none",

    // Each property can independently use the site's existing value or
    // the custom value from the extension.
    propertyModes: {
      fontSize: "override",
      fontWeight: "override",
      lineHeight: "override",
      letterSpacing: "override",
      wordSpacing: "override",
      textTransform: "override",
      fontStyle: "override",
      textDecoration: "override"
    },

    useHeadingFont: false,
    headingFontFamily: "Inter",
    headingFontStack: "\"Inter\", system-ui, sans-serif",
    headingWeight: 700,
    headingSizeScale: 1,
    loadedFontCss: "",
    loadedFontNames: [],
    ...state,

    propertyModes: {
      fontSize: "override",
      fontWeight: "override",
      lineHeight: "override",
      letterSpacing: "override",
      wordSpacing: "override",
      textTransform: "override",
      fontStyle: "override",
      textDecoration: "override",
      ...(state.propertyModes || {})
    }
  });

  const cssEscape = (value) => {
    try {
      return CSS.escape(String(value));
    } catch (_) {
      return String(value).replace(/[^a-zA-Z0-9_-]/g, (char) => `\\${char}`);
    }
  };

  const base64ToArrayBuffer = (base64) => {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);

    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }

    return bytes.buffer;
  };

  const fontFaceKey = (face) => [
    face.family || "",
    face.style || "normal",
    face.weight || "400",
    face.stretch || "normal",
    face.unicodeRange || ""
  ].join("|");

  const registerFontFaces = async (definitions, registry) => {
    const results = [];

    for (const definition of Array.isArray(definitions) ? definitions : []) {
      try {
        if (!definition?.family || !definition?.base64) {
          continue;
        }

        const key = fontFaceKey(definition);
        const existing = registry.get(key);

        if (existing) {
          results.push({
            ok: true,
            reused: true,
            family: definition.family
          });
          continue;
        }

        const face = new FontFace(
          definition.family,
          base64ToArrayBuffer(definition.base64),
          {
            style: definition.style || "normal",
            weight: definition.weight || "400",
            stretch: definition.stretch || "normal",
            unicodeRange: definition.unicodeRange || ""
          }
        );

        await face.load();
        document.fonts.add(face);
        registry.set(key, face);

        results.push({
          ok: true,
          family: definition.family
        });
      } catch (error) {
        results.push({
          ok: false,
          family: definition?.family || "",
          error: error instanceof Error ? error.message : String(error)
        });
      }
    }

    return results;
  };

  const clearRegisteredFaces = (registry) => {
    registry.forEach((face) => {
      try {
        document.fonts.delete(face);
      } catch (_) {}
    });

    registry.clear();
  };

  const getRuntimeStyle = () => {
    let style = document.getElementById(RUNTIME_STYLE_ID);
    if (!style) {
      style = document.createElement("style");
      style.id = RUNTIME_STYLE_ID;
      (document.head || document.documentElement).appendChild(style);
    }
    return style;
  };

  const installPickerStyle = () => {
    if (document.getElementById(PICKER_STYLE_ID)) return;

    const style = document.createElement("style");
    style.id = PICKER_STYLE_ID;
    style.textContent = `
      #${HOVER_ID},
      #${SELECTED_ID} {
        position: absolute !important;
        z-index: 2147483646 !important;
        pointer-events: none !important;
        display: none !important;
        box-sizing: border-box !important;
      }

      #${HOVER_ID} {
        display: none;
        border: 2px solid rgba(79, 70, 229, .95) !important;
        background: rgba(79, 70, 229, .07) !important;
        box-shadow: 0 0 0 1px rgba(255,255,255,.9) inset !important;
      }

      #${SELECTED_ID} {
        display: none;
        border: 2px solid rgba(16, 185, 129, .95) !important;
        background: rgba(16, 185, 129, .08) !important;
        box-shadow: 0 0 0 1px rgba(255,255,255,.9) inset !important;
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  };

  const removeMarkerAttributes = () => {
    document.querySelectorAll(`[${TEXT_MARK}], [${ROOT_MARK}], [${EXCLUDE_MARK}]`).forEach((element) => {
      element.removeAttribute(TEXT_MARK);
      element.removeAttribute(ROOT_MARK);
      element.removeAttribute(EXCLUDE_MARK);
    });
  };

  const removeRuntime = () => {
    document.documentElement.classList.remove("typology-lab-active");
    removeMarkerAttributes();

    const style = document.getElementById(RUNTIME_STYLE_ID);
    if (style) style.remove();

    clearRegisteredFaces(loadedGoogleFontFaces);
    clearRegisteredFaces(loadedCustomFontFaces);
  };

  const hasMeaningfulText = (element) => {
    const text = element?.textContent?.replace(/\s+/g, " ").trim() || "";
    return text.length > 0;
  };

  const isIconLike = (element) => {
    if (!(element instanceof Element)) return false;

    if (element.getAttribute("aria-hidden") === "true") return true;
    if (element.getAttribute("role") === "img") return true;
    if (element.matches("[hidden], [inert]")) return true;

    const className = typeof element.className === "string" ? element.className : "";
    if (ICON_CLASS_PATTERN.test(className)) return true;

    const style = window.getComputedStyle(element);
    const family = String(style.fontFamily || "").toLowerCase();

    if (/(material icons|material symbols|fontawesome|font awesome|dashicons|iconfont|icomoon|bootstrap-icons|lucide)/i.test(family)) {
      return true;
    }

    return false;
  };

  const isRenderableTextElement = (element, preserveIcons) => {
    if (!(element instanceof Element)) return false;

    const tag = element.tagName.toLowerCase();
    if (EXCLUDED_TAGS.has(tag)) return false;
    if (preserveIcons && isIconLike(element)) return false;

    const style = window.getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden") return false;

    const text = element.textContent?.replace(/\s+/g, " ").trim() || "";
    if (!text) return false;

    return true;
  };

  const getDirectTextParents = (root, preserveIcons) => {
    const result = new Set();

    if (!(root instanceof Element)) return result;

    const walker = document.createTreeWalker(
      root,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          if (!node.nodeValue || !node.nodeValue.replace(/\s+/g, "").length) {
            return NodeFilter.FILTER_REJECT;
          }

          let parent = node.parentElement;
          while (parent && parent !== root && !isRenderableTextElement(parent, preserveIcons)) {
            parent = parent.parentElement;
          }

          if (!parent || !isRenderableTextElement(parent, preserveIcons)) {
            if (root !== document.body && isRenderableTextElement(root, preserveIcons)) {
              return NodeFilter.FILTER_ACCEPT;
            }
            return NodeFilter.FILTER_REJECT;
          }

          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );

    let node;
    while ((node = walker.nextNode())) {
      let parent = node.parentElement;

      while (parent && parent !== root && !isRenderableTextElement(parent, preserveIcons)) {
        parent = parent.parentElement;
      }

      if (parent && isRenderableTextElement(parent, preserveIcons)) {
        result.add(parent);
      } else if (root !== document.body && isRenderableTextElement(root, preserveIcons)) {
        result.add(root);
      }
    }

    // Include direct root text when it itself owns text.
    if (root === document.body && hasMeaningfulText(root)) {
      // Body is intentionally not marked because its typography should be
      // applied to text-rendering descendants instead.
    }

    return result;
  };

  const getRootsForState = (state) => {
    switch (state.target) {
      case "headings":
        return Array.from(document.querySelectorAll("h1,h2,h3,h4,h5,h6"));

      case "body":
        return Array.from(document.querySelectorAll(
          "main, article, p, li, blockquote, figcaption, caption, dt, dd"
        ));

      case "navigation":
        return Array.from(document.querySelectorAll(
          "nav, [role='navigation'], [role='menubar'], header, footer, menu"
        ));

      case "buttons":
        return Array.from(document.querySelectorAll(
          "button, [role='button'], input[type='button'], input[type='submit'], a.button, .button"
        ));

      case "custom":
        if (!state.selector?.trim()) return [];
        try {
          return Array.from(document.querySelectorAll(state.selector.trim()));
        } catch (_) {
          return [];
        }

      case "site":
      default:
        return [document.body];
    }
  };

  const markTypographyTargets = (state) => {
    removeMarkerAttributes();

    const roots = getRootsForState(state);
    const renderTargets = new Set();

    roots.forEach((root) => {
      if (!(root instanceof Element)) return;

      root.setAttribute(ROOT_MARK, "1");

      if (state.target === "buttons") {
        if (isRenderableTextElement(root, state.preserveIcons)) {
          renderTargets.add(root);
        }
      }

      getDirectTextParents(root, Boolean(state.preserveIcons)).forEach((element) => {
        renderTargets.add(element);
      });
    });

    renderTargets.forEach((element) => {
      element.setAttribute(TEXT_MARK, "1");
    });

    return renderTargets;
  };

  const buildDeclarations = (state) => {
    const modes = state.propertyModes || {};

    const declarations = [];

    if (state.fontFamilyMode !== "site") {
      declarations.push(`font-family: ${state.fontStack} !important;`);
    }

    if (modes.fontSize !== "site") {
      declarations.push(`font-size: ${Number(state.fontSize)}px !important;`);
    }

    if (modes.fontWeight !== "site") {
      declarations.push(`font-weight: ${Number(state.fontWeight)} !important;`);
    }

    if (modes.lineHeight !== "site") {
      declarations.push(`line-height: ${Number(state.lineHeight)} !important;`);
    }

    if (modes.letterSpacing !== "site") {
      declarations.push(`letter-spacing: ${Number(state.letterSpacing)}px !important;`);
    }

    if (modes.wordSpacing !== "site") {
      declarations.push(`word-spacing: ${Number(state.wordSpacing)}px !important;`);
    }

    if (modes.textTransform !== "site") {
      declarations.push(`text-transform: ${state.textTransform} !important;`);
    }

    if (modes.fontStyle !== "site") {
      declarations.push(`font-style: ${state.fontStyle} !important;`);
    }

    if (modes.textDecoration !== "site") {
      declarations.push(`text-decoration-line: ${state.textDecoration} !important;`);
    }

    return declarations.join("\n    ");
  };

  const buildRuntimeCss = (state) => {
    let css = `
      /* Typography Lab v3 — browser-only preview */
      html.typology-lab-active [${TEXT_MARK}="1"] {
        ${buildDeclarations(state)}
      }

      html.typology-lab-active [${ROOT_MARK}="1"] [${TEXT_MARK}="1"] {
        text-rendering: optimizeLegibility !important;
      }
    `;

    if (state.useHeadingFont &&
        state.headingFontStack &&
        state.fontFamilyMode !== "site") {
      css += `
        html.typology-lab-active h1,
        html.typology-lab-active h2,
        html.typology-lab-active h3,
        html.typology-lab-active h4,
        html.typology-lab-active h5,
        html.typology-lab-active h6,
        html.typology-lab-active h1 [${TEXT_MARK}="1"],
        html.typology-lab-active h2 [${TEXT_MARK}="1"],
        html.typology-lab-active h3 [${TEXT_MARK}="1"],
        html.typology-lab-active h4 [${TEXT_MARK}="1"],
        html.typology-lab-active h5 [${TEXT_MARK}="1"],
        html.typology-lab-active h6 [${TEXT_MARK}="1"] {
          font-family: ${state.headingFontStack} !important;
        }
      `;

      if (state.propertyModes?.fontWeight !== "site") {
        css += `
          html.typology-lab-active h1,
          html.typology-lab-active h2,
          html.typology-lab-active h3,
          html.typology-lab-active h4,
          html.typology-lab-active h5,
          html.typology-lab-active h6,
          html.typology-lab-active h1 [${TEXT_MARK}="1"],
          html.typology-lab-active h2 [${TEXT_MARK}="1"],
          html.typology-lab-active h3 [${TEXT_MARK}="1"],
          html.typology-lab-active h4 [${TEXT_MARK}="1"],
          html.typology-lab-active h5 [${TEXT_MARK}="1"],
          html.typology-lab-active h6 [${TEXT_MARK}="1"] {
            font-weight: ${Number(state.headingWeight)} !important;
          }
        `;
      }

      if (state.propertyModes?.fontSize !== "site") {
        const scale = Math.max(0.1, Number(state.headingSizeScale) || 1);

        css += `
          html.typology-lab-active h1 [${TEXT_MARK}="1"] {
            font-size: calc(${Number(state.fontSize)}px * ${scale}) !important;
          }
          html.typology-lab-active h2 [${TEXT_MARK}="1"] {
            font-size: calc(${Number(state.fontSize)}px * ${Math.max(scale * .86, .1)}) !important;
          }
          html.typology-lab-active h3 [${TEXT_MARK}="1"] {
            font-size: calc(${Number(state.fontSize)}px * ${Math.max(scale * .74, .1)}) !important;
          }
        `;
      }
    }

    return css;
  };

  const applyState = (incomingState = {}) => {
    lastState = normalizeState(incomingState);

    if (!lastState.enabled) {
      removeRuntime();
      return {
        ok: true,
        count: 0
      };
    }

    document.documentElement.classList.add("typology-lab-active");

    const count = markTypographyTargets(lastState);
    const style = getRuntimeStyle();
    style.textContent = buildRuntimeCss(lastState);

    // If a dynamic page replaces nodes, the observer will mark them again.
    startObserver();

    return {
      ok: true,
      count: count.size
    };
  };

  const startObserver = () => {
    if (observer) return;

    observer = new MutationObserver(() => {
      if (!lastState?.enabled) return;

      clearTimeout(reapplyTimer);
      reapplyTimer = setTimeout(() => {
        markTypographyTargets(lastState);
      }, 120);
    });

    observer.observe(document.documentElement, {
      subtree: true,
      childList: true,
      characterData: true
    });
  };

  const stopObserver = () => {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    clearTimeout(reapplyTimer);
  };

  const buildSelector = (element) => {
    if (!(element instanceof Element)) return "";

    if (element.id) {
      return `#${cssEscape(element.id)}`;
    }

    const parts = [];
    let current = element;
    let depth = 0;

    while (current && current.nodeType === Node.ELEMENT_NODE && current !== document.body && depth < 8) {
      let part = current.tagName.toLowerCase();

      const stableClasses = Array.from(current.classList || [])
        .filter((name) => {
          if (!name || name.length > 50) return false;
          return !/^(wp-|elementor-|e-|jsx-|css-|sc-|ng-|v-|is-|has-)/i.test(name);
        })
        .slice(0, 2);

      if (stableClasses.length) {
        part += stableClasses.map((name) => `.${cssEscape(name)}`).join("");
      }

      const parent = current.parentElement;
      if (parent) {
        const sameTag = Array.from(parent.children).filter((child) => child.tagName === current.tagName);
        if (sameTag.length > 1) {
          part += `:nth-of-type(${sameTag.indexOf(current) + 1})`;
        }
      }

      parts.unshift(part);

      const candidate = parts.join(" > ");
      try {
        if (document.querySelectorAll(candidate).length === 1) {
          return candidate;
        }
      } catch (_) {}

      current = current.parentElement;
      depth += 1;
    }

    return parts.join(" > ");
  };

  const getElementInfo = (element) => {
    if (!(element instanceof Element)) return null;

    const style = window.getComputedStyle(element);
    const rect = element.getBoundingClientRect();

    return {
      tagName: element.tagName.toLowerCase(),
      id: element.id || "",
      classes: Array.from(element.classList || []).slice(0, 10),
      text: (element.innerText || element.textContent || "").trim().replace(/\s+/g, " ").slice(0, 220),
      selector: buildSelector(element),
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      fontWeight: style.fontWeight,
      lineHeight: style.lineHeight,
      letterSpacing: style.letterSpacing,
      wordSpacing: style.wordSpacing,
      textTransform: style.textTransform,
      fontStyle: style.fontStyle,
      textDecoration: style.textDecorationLine,
      display: style.display,
      color: style.color,
      width: Math.round(rect.width),
      height: Math.round(rect.height)
    };
  };

  const getSelectedApplicationState = () => {
    if (!(selectedElement instanceof Element)) {
      return null;
    }

    const computed = window.getComputedStyle(selectedElement);

    return {
      selector: buildSelector(selectedElement),
      tagName: selectedElement.tagName.toLowerCase(),
      fontFamily: computed.fontFamily,
      fontSize: computed.fontSize,
      fontWeight: computed.fontWeight,
      lineHeight: computed.lineHeight,
      letterSpacing: computed.letterSpacing,
      wordSpacing: computed.wordSpacing,
      textTransform: computed.textTransform,
      fontStyle: computed.fontStyle,
      textDecoration: computed.textDecorationLine
    };
  };

  const getTypographyNodesForReport = () => {
    const nodes = new Set();

    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          if (!node.nodeValue || !node.nodeValue.replace(/\s+/g, "").length) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );

    let textNode;
    while ((textNode = walker.nextNode())) {
      let parent = textNode.parentElement;

      while (
        parent &&
        parent !== document.body &&
        (!isRenderableTextElement(parent, true) || parent.tagName.toLowerCase() === "body")
      ) {
        parent = parent.parentElement;
      }

      if (parent && parent !== document.body && isRenderableTextElement(parent, true)) {
        nodes.add(parent);
      }
    }

    return nodes;
  };

  const getFontReport = () => {
    const counts = new Map();

    const add = (family) => {
      const value = String(family || "").trim();
      if (!value) return;

      const primary = value.split(",")[0].replace(/["']/g, "").trim();
      if (!primary) return;

      const item = counts.get(primary) || {
        family: primary,
        count: 0
      };

      item.count += 1;
      counts.set(primary, item);
    };

    getTypographyNodesForReport().forEach((element) => {
      try {
        add(window.getComputedStyle(element).fontFamily);
      } catch (_) {}
    });

    try {
      document.fonts?.forEach((face) => {
        if (face.family) add(face.family);
      });
    } catch (_) {}

    return Array.from(counts.values())
      .sort((a, b) => b.count - a.count)
      .slice(0, 30);
  };

  const getPageScan = () => ({
    title: document.title || location.hostname,
    url: location.href,
    hostname: location.hostname,
    headings: document.querySelectorAll("h1,h2,h3,h4,h5,h6").length,
    paragraphs: document.querySelectorAll("p").length,
    links: document.querySelectorAll("a").length,
    buttons: document.querySelectorAll("button,[role='button'],input[type='button'],input[type='submit']").length,
    textNodes: getTypographyNodesForReport().size
  });

  const createHighlight = (id) => {
    installPickerStyle();

    let highlight = document.getElementById(id);
    if (!highlight) {
      highlight = document.createElement("div");
      highlight.id = id;
      document.documentElement.appendChild(highlight);
    }

    return highlight;
  };

  const positionHighlight = (highlight, element) => {
    if (!highlight || !(element instanceof Element) || element === document.documentElement) {
      if (highlight) highlight.style.display = "none";
      return;
    }

    const rect = element.getBoundingClientRect();

    if (!rect || rect.width <= 0 || rect.height <= 0) {
      highlight.style.display = "none";
      return;
    }

    highlight.style.display = "block";
    highlight.style.top = `${rect.top + window.scrollY}px`;
    highlight.style.left = `${rect.left + window.scrollX}px`;
    highlight.style.width = `${rect.width}px`;
    highlight.style.height = `${rect.height}px`;
  };

  const removeHighlight = (id) => {
    const element = document.getElementById(id);
    if (element) element.remove();
  };

  const repositionSelected = () => {
    const selectedHighlight = document.getElementById(SELECTED_ID);
    if (selectedHighlight && selectedElement) {
      positionHighlight(selectedHighlight, selectedElement);
    }
  };

  const onPickerMove = (event) => {
    if (!pickerActive) return;

    const target = document.elementFromPoint(event.clientX, event.clientY);
    if (!(target instanceof Element)) return;

    if (
      target.id === HOVER_ID ||
      target.id === SELECTED_ID ||
      target.closest(`#${HOVER_ID}, #${SELECTED_ID}`)
    ) {
      return;
    }

    if (target === pickerHover) return;
    pickerHover = target;

    const hover = createHighlight(HOVER_ID);
    positionHighlight(hover, target);
  };

  const onPickerClick = (event) => {
    if (!pickerActive) return;

    const target = event.target;
    if (!(target instanceof Element)) return;

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();

    selectedElement = target;
    lastInfo = getElementInfo(target);

    stopPicker(false);

    const selected = createHighlight(SELECTED_ID);
    positionHighlight(selected, target);

    window.addEventListener("scroll", repositionSelected, true);
    window.addEventListener("resize", repositionSelected, true);

    chrome.runtime.sendMessage({
      type: "TYPOGRAPHY_LAB_ELEMENT_SELECTED",
      info: lastInfo
    }).catch(() => {});
  };

  const startPicker = () => {
    stopPicker(true);

    installPickerStyle();
    pickerActive = true;
    pickerHover = null;

    document.documentElement.style.setProperty("cursor", "crosshair", "important");

    document.addEventListener("mousemove", onPickerMove, true);
    document.addEventListener("click", onPickerClick, true);
  };

  const stopPicker = (removeSelected) => {
    pickerActive = false;
    pickerHover = null;

    document.documentElement.style.removeProperty("cursor");
    document.removeEventListener("mousemove", onPickerMove, true);
    document.removeEventListener("click", onPickerClick, true);

    const hover = document.getElementById(HOVER_ID);
    if (hover) hover.style.display = "none";

    if (removeSelected) {
      window.removeEventListener("scroll", repositionSelected, true);
      window.removeEventListener("resize", repositionSelected, true);
      removeHighlight(SELECTED_ID);
      selectedElement = null;
      lastInfo = null;
    }
  };

  const selectBySelector = (selector) => {
    try {
      const element = document.querySelector(selector);
      if (element) {
        selectedElement = element;
        lastInfo = getElementInfo(element);

        const selected = createHighlight(SELECTED_ID);
        positionHighlight(selected, element);

        window.addEventListener("scroll", repositionSelected, true);
        window.addEventListener("resize", repositionSelected, true);

        return lastInfo;
      }
    } catch (_) {}

    return null;
  };

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    try {
      switch (message?.type) {
        case "TYPOGRAPHY_LAB_LOAD_GOOGLE_FONTS":
          if (message.replaceExisting) {
            clearRegisteredFaces(loadedGoogleFontFaces);
          }

          registerFontFaces(
            message.faces,
            loadedGoogleFontFaces
          ).then((results) => {
            sendResponse({
              ok: results.some((result) => result.ok),
              loaded: results.filter((result) => result.ok).length,
              failed: results.filter((result) => !result.ok).length,
              results
            });
          });

          return true;

        case "TYPOGRAPHY_LAB_LOAD_CUSTOM_FONT":
          registerFontFaces(
            [message.face],
            loadedCustomFontFaces
          ).then((results) => {
            const result = results[0] || {
              ok: false,
              error: "No font supplied."
            };

            sendResponse({
              ok: Boolean(result.ok),
              loaded: result.ok ? 1 : 0,
              failed: result.ok ? 0 : 1,
              result
            });
          });

          return true;

        case "TYPOGRAPHY_LAB_CLEAR_FONT_FACES":
          clearRegisteredFaces(loadedGoogleFontFaces);
          clearRegisteredFaces(loadedCustomFontFaces);

          sendResponse({ ok: true });
          break;

        case "TYPOGRAPHY_LAB_PING":
          sendResponse({
            ok: true,
            version: "0.3.0",
            scan: getPageScan(),
            state: lastState
          });
          break;

        case "TYPOGRAPHY_LAB_APPLY": {
          const result = applyState(message.state || {});

          sendResponse({
            ...result,
            runtimeCss: lastState?.enabled
              ? buildRuntimeCss(lastState)
              : "",
            selectedApplication: getSelectedApplicationState(),
            scan: getPageScan()
          });
          break;
        }

        case "TYPOGRAPHY_LAB_START_PICKER":
          startPicker();
          sendResponse({ ok: true });
          break;

        case "TYPOGRAPHY_LAB_STOP_PICKER":
          stopPicker(false);
          sendResponse({ ok: true });
          break;

        case "TYPOGRAPHY_LAB_RESET":
          stopPicker(true);
          stopObserver();
          lastState = null;
          removeRuntime();
          sendResponse({ ok: true });
          break;

        case "TYPOGRAPHY_LAB_SCAN":
          sendResponse({
            ok: true,
            scan: getPageScan()
          });
          break;

        case "TYPOGRAPHY_LAB_FONT_REPORT":
          sendResponse({
            ok: true,
            fonts: getFontReport()
          });
          break;

        case "TYPOGRAPHY_LAB_SELECT_SELECTOR":
          sendResponse({
            ok: true,
            info: selectBySelector(message.selector || "")
          });
          break;

        case "TYPOGRAPHY_LAB_GET_SELECTED":
          sendResponse({
            ok: true,
            info: selectedElement ? getElementInfo(selectedElement) : lastInfo,
            application: getSelectedApplicationState()
          });
          break;

        case "TYPOGRAPHY_LAB_CLEAR_SELECTION":
          window.removeEventListener("scroll", repositionSelected, true);
          window.removeEventListener("resize", repositionSelected, true);
          removeHighlight(SELECTED_ID);
          selectedElement = null;
          lastInfo = null;
          sendResponse({ ok: true });
          break;

        default:
          sendResponse({ ok: false, error: "Unknown message." });
      }
    } catch (error) {
      sendResponse({
        ok: false,
        error: error instanceof Error ? error.message : String(error)
      });
    }

    return true;
  });
})();