const configureSidePanel = () => {
  chrome.sidePanel.setPanelBehavior({
    openPanelOnActionClick: true
  }).catch((error) => {
    console.error("Typography Lab: side panel configuration failed.", error);
  });
};

configureSidePanel();

chrome.runtime.onInstalled.addListener(() => {
  configureSidePanel();
});