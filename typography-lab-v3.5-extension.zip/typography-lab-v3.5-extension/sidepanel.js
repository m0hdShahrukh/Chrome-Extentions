(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);

  const BUILTIN_FONTS = [
    "Inter","Roboto","Poppins","Montserrat","Manrope","DM Sans",
    "Plus Jakarta Sans","Figtree","Outfit","Open Sans","Lato",
    "Source Sans 3","Nunito Sans","Raleway","Space Grotesk",
    "Work Sans","IBM Plex Sans","IBM Plex Serif","Merriweather",
    "Playfair Display","Libre Baskerville","Bebas Neue","Oswald",
    "Archivo","Archivo Narrow","Afacad","Albert Sans","Geist",
    "Geist Mono","Barlow","Barlow Condensed","Cabin","Cardo",
    "Chivo","Comfortaa","Cormorant Garamond","Crimson Text",
    "Exo 2","Heebo","Inconsolata","Josefin Sans","Karla","Lexend",
    "Mulish","Noto Sans","Noto Serif","PT Sans","Quicksand",
    "Roboto Condensed","Rubik","Sora","Spectral","Titillium Web",
    "Urbanist","Vollkorn","Yanone Kaffeesatz","Arial","Helvetica",
    "Georgia","Verdana","Trebuchet MS","Times New Roman","System UI"
  ];

  const DEFAULT_STATE = {
    enabled: true,
    target: "site",
    selector: "",
    preserveIcons: true,
    fontFamily: "Inter",
    fontStack: "\"Inter\", system-ui, -apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif",
    fontFamilyMode: "override",
    fontSize: 16,
    fontWeight: 400,
    lineHeight: 1.6,
    letterSpacing: 0,
    wordSpacing: 0,
    textTransform: "none",
    fontStyle: "normal",
    textDecoration: "none",
    propertyModes: {
      fontSize: "override",
      fontWeight: "override",
      lineHeight: "override",
      letterSpacing: "override",
      wordSpacing: "override",
      textTransform: "override",
      fontStyle: "override",
      textDecoration: "override"
    },
    useHeadingFont: false,
    headingFontFamily: "Inter",
    headingFontStack: "\"Inter\", system-ui, sans-serif",
    headingWeight: 700,
    headingSizeScale: 1,
    loadedFontCss: "",
    loadedFontNames: []
  };

  let state = { ...DEFAULT_STATE };
  let presets = [];
  let fontCatalog = [];
  let catalogLoadedFrom = "";
  let currentTabId = null;
  let toastTimer = null;
  let applyTimer = null;
  let selectedInfo = null;
  let lastInjectedFontCss = "";
  let lastCustomFontCss = "";
  let lastUserTypographyCss = "";
  let googleApiKey = "";
  let refreshSequence = 0;
  let fontListDisplayLimit = 250;
  let customFonts = [];
  let currentGoogleFontToken = 0;

  const showToast = (message) => {
    const toast = $("toast");
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 1800);
  };

  const normalizeState = (saved = {}) => ({
    ...DEFAULT_STATE,
    ...(saved || {}),
    headingSizeScale: Number(saved?.headingSizeScale ?? DEFAULT_STATE.headingSizeScale)
  });

  const escapeHtml = (value) => String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

  const fontStackFor = (family) =>
    `"${String(family).replaceAll('"', '\\"')}", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`;

  const getTabs = () =>
    chrome.tabs.query({ active: true, currentWindow: true });

  const ensureContentScript = async (tabId) => {
    try {
      await chrome.tabs.sendMessage(tabId, {
        type: "TYPOGRAPHY_LAB_PING"
      });
      return true;
    } catch (_) {}

    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["content.js"]
      });

      await chrome.tabs.sendMessage(tabId, {
        type: "TYPOGRAPHY_LAB_PING"
      });

      return true;
    } catch (error) {
      throw new Error(
        error?.message ||
        "This page does not allow extensions to modify it."
      );
    }
  };

  const getActiveTab = async () => {
    const tabs = await getTabs();
    const tab = tabs[0];

    if (!tab?.id) {
      throw new Error("No active browser tab was found.");
    }

    currentTabId = tab.id;
    await ensureContentScript(tab.id);
    return tab;
  };

  const sendToPage = async (message) => {
    const tab = await getActiveTab();
    return chrome.tabs.sendMessage(tab.id, message);
  };

  const updateAccessNotice = (error = null) => {
    const notice = $("accessNotice");

    if (!error) {
      notice.classList.add("hidden");
      return;
    }

    notice.classList.remove("hidden");

    const message = String(error?.message || error);
    $("accessMessage").textContent = /Cannot access|not allowed|extensions|chrome:\/\//i.test(message)
      ? "This page is protected by the browser, or site access is disabled. Open the extension Details page and set Site access to “On all sites”, then reload the website."
      : message;
  };

  const updatePageStats = (scan) => {
    if (!scan) return;

    $("pageStatus").textContent = scan.title || scan.hostname || "Active page";
    $("statHeadings").textContent = scan.headings ?? "—";
    $("statParagraphs").textContent = scan.paragraphs ?? "—";
    $("statLinks").textContent = scan.links ?? "—";
    $("statTextNodes").textContent = scan.textNodes ?? "—";
  };

  const refreshPage = async () => {
    try {
      const result = await sendToPage({
        type: "TYPOGRAPHY_LAB_SCAN"
      });
      updatePageStats(result?.scan);
      updateAccessNotice(null);
      return result;
    } catch (error) {
      $("pageStatus").textContent = error.message || "Page access unavailable";
      updateAccessNotice(error);
      throw error;
    }
  };

  const TYPOGRAPHY_PROPERTIES = [
    "fontSize",
    "fontWeight",
    "lineHeight",
    "letterSpacing",
    "wordSpacing",
    "textTransform",
    "fontStyle",
    "textDecoration"
  ];

  const ensurePropertyModes = () => {
    if (!state.propertyModes || typeof state.propertyModes !== "object") {
      state.propertyModes = {};
    }

    TYPOGRAPHY_PROPERTIES.forEach((property) => {
      if (state.propertyModes[property] !== "site" &&
          state.propertyModes[property] !== "override") {
        state.propertyModes[property] = "override";
      }
    });
  };

  const isPropertyOverride = (property) => {
    ensurePropertyModes();
    return state.propertyModes[property] === "override";
  };

  const setPropertyMode = (property, mode) => {
    ensurePropertyModes();
    state.propertyModes[property] = mode === "site" ? "site" : "override";
    syncPropertyModeUi();
    updateExport();
    scheduleApply();
  };

  const syncPropertyModeUi = () => {
    ensurePropertyModes();

    TYPOGRAPHY_PROPERTIES.forEach((property) => {
      const mode = state.propertyModes[property];

      const control = document.querySelector(
        `.property-control .mode-row[data-property="${property}"]`
      )?.closest(".property-control");

      if (control) {
        control.classList.toggle("is-site", mode === "site");
      }

      const input = $(property);
      if (input) {
        input.disabled = mode === "site";
      }

      const hint = $(`${property}ModeHint`);
      if (hint) {
        hint.textContent = mode === "site"
          ? "Using website value"
          : "Custom value";
      }

      document
        .querySelectorAll(`input[name="mode-${property}"]`)
        .forEach((radio) => {
          radio.checked = radio.value === mode;
        });
    });
  };

  const setFontFamilyOnlyMode = () => {
    ensurePropertyModes();

    TYPOGRAPHY_PROPERTIES.forEach((property) => {
      state.propertyModes[property] = "site";
    });

    state.fontFamilyMode = "override";

    syncPropertyModeUi();
    updateFontFamilyModeUi();
    updateExport();
    scheduleApply();
    showToast("Font family only mode enabled.");
  };

  const setFontFamilyMode = (mode) => {
    state.fontFamilyMode = mode === "site" ? "site" : "override";
    updateFontFamilyModeUi();
    updateExport();
    scheduleApply();
  };

  const updateFontFamilyModeUi = () => {
    const button = $("originalSiteFontBtn");
    if (!button) return;

    const isOriginal = state.fontFamilyMode === "site";

    button.classList.toggle("active", isOriginal);
    button.textContent = isOriginal
      ? "Using original site font"
      : "Original site font";
  };

  const setExtensionEnabled = async (enabled, options = {}) => {
    state.enabled = Boolean(enabled);

    if (!state.enabled) {
      try {
        await sendToPage({
          type: "TYPOGRAPHY_LAB_RESET"
        });
      } catch (_) {}

      await removeUserTypographyCss();

      if (lastInjectedFontCss && currentTabId) {
        try {
          await chrome.scripting.removeCSS({
            target: { tabId: currentTabId },
            css: lastInjectedFontCss
          });
        } catch (_) {}
      }

      if (lastCustomFontCss && currentTabId) {
        try {
          await chrome.scripting.removeCSS({
            target: { tabId: currentTabId },
            css: lastCustomFontCss
          });
        } catch (_) {}
      }

      lastInjectedFontCss = "";
      lastCustomFontCss = "";
    } else if (options.apply !== false) {
      await applyPreview();
    }

    updateExtensionUi();
    await chrome.storage.local.set({ typographyLabState: state });
  };

  const updateExtensionUi = () => {
    const checkbox = $("extensionEnabled");
    const label = $("extensionEnabledLabel");

    if (!checkbox) return;

    checkbox.checked = Boolean(state.enabled);
    label.textContent = state.enabled
      ? "Extension on"
      : "Extension off";

    checkbox.closest(".extension-toggle")?.classList.toggle(
      "is-off",
      !state.enabled
    );

    $("applyBtn").disabled = !state.enabled;
  };

  const updateOutputs = () => {
    $("fontSizeOut").textContent = `${Number(state.fontSize).toFixed(0)} px`;
    $("lineHeightOut").textContent = Number(state.lineHeight).toFixed(2);
    $("letterSpacingOut").textContent = `${Number(state.letterSpacing).toFixed(1)} px`;
    $("wordSpacingOut").textContent = `${Number(state.wordSpacing).toFixed(1)} px`;
    $("headingScaleOut").textContent = `${Number(state.headingSizeScale).toFixed(2)}×`;
  };

  const updateFontPreview = () => {
    const preview = $("fontPreview");
    preview.style.fontFamily = state.fontStack;
    preview.style.fontSize = `${Math.max(13, Number(state.fontSize) + 1)}px`;
    preview.style.fontWeight = state.fontWeight;
    preview.style.lineHeight = state.lineHeight;
    preview.style.letterSpacing = `${state.letterSpacing}px`;
  };

  const updateControls = () => {
    $("preserveIcons").checked = Boolean(state.preserveIcons);
    $("fontSize").value = state.fontSize;
    $("fontWeight").value = String(state.fontWeight);
    $("lineHeight").value = state.lineHeight;
    $("letterSpacing").value = state.letterSpacing;
    $("wordSpacing").value = state.wordSpacing;
    $("textTransform").value = state.textTransform;
    $("fontStyle").value = state.fontStyle;
    $("textDecoration").value = state.textDecoration;

    $("fontFallback").value = state.fontStack
      .replace(/^"[^"]+",\s*/, "")
      .replace(/^'[^']+',\s*/, "");

    document.querySelectorAll(".target-button").forEach((button) => {
      button.classList.toggle("active", button.dataset.target === state.target);
    });

    $("customSelectorWrap").classList.toggle(
      "hidden",
      state.target !== "custom"
    );

    $("customSelector").value = state.selector;

    $("useHeadingFont").checked = Boolean(state.useHeadingFont);
    $("headingControls").classList.toggle("hidden", !state.useHeadingFont);
    $("headingWeight").value = String(state.headingWeight);
    $("headingScale").value = state.headingSizeScale;

    ensurePropertyModes();
    syncPropertyModeUi();
    updateFontFamilyModeUi();
    updateExtensionUi();

    updateOutputs();
    updateFontPreview();
    updateExport();
  };

  const updateSelectedElement = (info) => {
    selectedInfo = info || null;
    const box = $("selectedElement");

    if (!info) {
      box.classList.add("empty");
      box.textContent = "Nothing selected.";
      return;
    }

    box.classList.remove("empty");
    box.innerHTML = "";

    const title = document.createElement("div");
    title.innerHTML =
      `<span class="tag">${escapeHtml(info.tagName)}</span>` +
      (info.id ? ` #${escapeHtml(info.id)}` : "");

    const text = document.createElement("div");
    text.className = "meta";
    text.textContent = info.text || "(no readable text)";

    const selector = document.createElement("div");
    selector.className = "meta";
    selector.textContent = info.selector || "(no unique selector)";

    const type = document.createElement("div");
    type.className = "meta";
    type.textContent =
      `${info.fontFamily} · ${info.fontSize} · weight ${info.fontWeight} · line ${info.lineHeight}`;

    box.append(title, text, selector, type);
  };

  const setFontLoadStatus = (message, type = "") => {
    const element = $("fontLoadStatus");
    if (!element) return;

    element.textContent = message;
    element.classList.remove("success", "error");

    if (type) element.classList.add(type);
  };

  const extractCssDeclaration = (block, property) => {
    const expression = new RegExp(
      `${property}\\s*:\\s*([^;]+)`,
      "i"
    );

    return block.match(expression)?.[1]?.trim() || "";
  };

  const parseGoogleFontFaces = (cssText) => {
    const faces = [];
    const seen = new Set();
    const expression = /@font-face\s*\{([\s\S]*?)\}/gi;
    let match;

    while ((match = expression.exec(cssText))) {
      const block = match[1];

      const family = extractCssDeclaration(
        block,
        "font-family"
      ).replace(/^["']|["']$/g, "").trim();

      const style =
        extractCssDeclaration(block, "font-style") ||
        "normal";

      const weight =
        extractCssDeclaration(block, "font-weight") ||
        "400";

      const stretch =
        extractCssDeclaration(block, "font-stretch") ||
        "normal";

      const unicodeRange =
        extractCssDeclaration(block, "unicode-range");

      const urlMatches = [
        ...block.matchAll(/url\(\s*["']?(https:\/\/[^)"']+)["']?\s*\)/gi)
      ];

      const fontUrl = urlMatches
        .map((item) => item[1])
        .find((url) =>
          /^https:\/\/fonts\.(?:gstatic\.com|googleapis\.com)\//i.test(url)
        );

      if (!family || !fontUrl) {
        continue;
      }

      const key = [
        family,
        style,
        weight,
        stretch,
        unicodeRange,
        fontUrl
      ].join("|");

      if (seen.has(key)) continue;
      seen.add(key);

      faces.push({
        family,
        style,
        weight,
        stretch,
        unicodeRange,
        url: fontUrl
      });
    }

    return faces;
  };

  const arrayBufferToBase64 = (buffer) => {
    const bytes = new Uint8Array(buffer);
    const chunkSize = 0x8000;
    let binary = "";

    for (let i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode(
        ...bytes.subarray(i, i + chunkSize)
      );
    }

    return btoa(binary);
  };

  const buildGoogleFontsCssUrl = (family) => {
    // IMPORTANT:
    // Let URLSearchParams encode spaces in the query. For example:
    // "Rethink Sans" -> family=Rethink+Sans
    // Do not pre-replace spaces with '+' and then encode them as %2B.
    const params = new URLSearchParams();
    params.set("family", family);
    params.set("display", "swap");

    return `https://fonts.googleapis.com/css2?${params.toString()}`;
  };

  const fetchGoogleFontFaces = async (family) => {
    const url = buildGoogleFontsCssUrl(family);

    const response = await fetch(url, {
      cache: "no-store",
      credentials: "omit",
      referrerPolicy: "no-referrer"
    });

    if (!response.ok) {
      throw new Error(
        `Google Fonts CSS request failed (${response.status}).`
      );
    }

    const cssText = await response.text();
    const parsed = parseGoogleFontFaces(cssText);

    if (!parsed.length) {
      throw new Error(
        `Google Fonts returned no font files for “${family}”.`
      );
    }

    const faces = [];

    for (const item of parsed) {
      try {
        const fontResponse = await fetch(item.url, {
          cache: "force-cache",
          credentials: "omit",
          referrerPolicy: "no-referrer"
        });

        if (!fontResponse.ok) continue;

        const buffer = await fontResponse.arrayBuffer();
        if (!buffer.byteLength) continue;

        faces.push({
          family: item.family,
          style: item.style,
          weight: item.weight,
          stretch: item.stretch,
          unicodeRange: item.unicodeRange,
          base64: arrayBufferToBase64(buffer)
        });
      } catch (_) {
        // Ignore one subset failure and keep the other subsets.
      }
    }

    if (!faces.length) {
      throw new Error(
        `The Google font files for “${family}” could not be downloaded.`
      );
    }

    return {
      cssText,
      faces
    };
  };

  const loadGoogleFontIntoPage = async (family) => {
    const token = ++currentGoogleFontToken;

    setFontLoadStatus(
      `Loading ${family} from Google Fonts…`
    );

    const data = await fetchGoogleFontFaces(family);

    if (token !== currentGoogleFontToken) {
      return false;
    }

    const result = await sendToPage({
      type: "TYPOGRAPHY_LAB_LOAD_GOOGLE_FONTS",
      faces: data.faces,
      replaceExisting: true
    });

    if (!result?.loaded) {
      throw new Error(
        `${family} was downloaded, but the browser could not register its font files.`
      );
    }

    setFontLoadStatus(
      `${family} loaded successfully · ${result.loaded} font face${result.loaded === 1 ? "" : "s"}`,
      "success"
    );

    return true;
  };

  const setFont = async (family, options = {}) => {
    const cleanFamily = String(family || "").trim();
    if (!cleanFamily) return false;

    state.fontFamily = cleanFamily;
    state.fontStack =
      options.stack || fontStackFor(cleanFamily);
    state.fontFamilyMode = "override";

    if (!state.fontStack.includes("Typography Lab Custom")) {
      state.loadedFontCss = "";
    }

    updateControls();

    if (
      options.loadGoogle !== false &&
      !state.fontStack.includes("Typography Lab Custom")
    ) {
      try {
        await loadGoogleFontIntoPage(cleanFamily);
      } catch (error) {
        setFontLoadStatus(
          `Could not load ${cleanFamily}: ${error.message || "unknown error"}`,
          "error"
        );
        showToast(`Font failed: ${cleanFamily}`);
        return false;
      }
    }

    await applyPreview();
    return true;
  };

  // Compatibility wrapper for older preset/state code.
  const loadGoogleFontCss = async (family) => {
    return loadGoogleFontIntoPage(family);
  };

  const replaceInjectedFontCss = async (css) => {
    if (!currentTabId) return;

    if (lastInjectedFontCss) {
      try {
        await chrome.scripting.removeCSS({
          target: { tabId: currentTabId },
          css: lastInjectedFontCss
        });
      } catch (_) {}
    }

    lastInjectedFontCss = css || "";

    if (lastInjectedFontCss) {
      try {
        await chrome.scripting.insertCSS({
          target: { tabId: currentTabId },
          css: lastInjectedFontCss
        });
      } catch (_) {
        // Content-script style fallback is already carried in state.
      }
    }
  };

  const scheduleApply = () => {
    clearTimeout(applyTimer);
    applyTimer = setTimeout(() => {
      applyPreview().catch(() => {});
    }, 70);
  };

  const removeUserTypographyCss = async () => {
    if (!currentTabId || !lastUserTypographyCss) return;

    try {
      await chrome.scripting.removeCSS({
        target: {
          tabId: currentTabId,
          allFrames: true
        },
        css: lastUserTypographyCss,
        origin: "USER"
      });
    } catch (_) {}

    lastUserTypographyCss = "";
  };

  const injectUserTypographyCss = async (css) => {
    if (!currentTabId || !css) return;

    await removeUserTypographyCss();

    await chrome.scripting.insertCSS({
      target: {
        tabId: currentTabId,
        allFrames: true
      },
      css,
      origin: "USER"
    });

    lastUserTypographyCss = css;
  };

  const renderApplicationState = (application) => {
    const box = $("selectedApplication");
    if (!box) return;

    if (!application) {
      box.classList.add("hidden");
      box.textContent = "";
      return;
    }

    box.classList.remove("hidden");
    box.innerHTML = "";

    const heading = document.createElement("strong");
    heading.textContent = "Computed typography after preview";

    const details = document.createElement("span");
    details.textContent =
      `${application.fontFamily} · ${application.fontSize} · weight ${application.fontWeight} · line ${application.lineHeight}`;

    box.append(heading, details);
  };

  const applyPreview = async () => {
    if (state.enabled === false) {
      return {
        ok: true,
        disabled: true
      };
    }

    updateControls();

    const result = await sendToPage({
      type: "TYPOGRAPHY_LAB_APPLY",
      state
    });

    if (result?.runtimeCss) {
      try {
        await injectUserTypographyCss(result.runtimeCss);
      } catch (error) {
        console.warn(
          "Typography Lab USER CSS injection failed:",
          error
        );
      }
    }

    updatePageStats(result?.scan);
    renderApplicationState(result?.selectedApplication);
    updateExport();

    await chrome.storage.local.set({
      typographyLabState: state
    });

    return result;
  };

  const getTargetSelectorForExport = () => {
    switch (state.target) {
      case "headings":
        return "h1, h2, h3, h4, h5, h6";

      case "body":
        return "main p, main li, article p, article li, blockquote, figcaption";

      case "navigation":
        return "nav, nav *, [role='navigation'], [role='navigation'] *, header, footer, menu";

      case "buttons":
        return "button, [role='button'], input[type='button'], input[type='submit'], .button";

      case "custom":
        return state.selector.trim() || "/* add a selector */";

      case "site":
      default:
        return "body p, body li, body a, body label, body input, body textarea, body select, body button, body table, body th, body td, body blockquote, body h1, body h2, body h3, body h4, body h5, body h6, body figcaption, body caption, body dt, body dd";
    }
  };

  const updateExport = () => {
    const selector = getTargetSelectorForExport();

    ensurePropertyModes();

    ensurePropertyModes();

    let css = `/* Typography Lab v3.3 export */\n${selector} {\n`;

    if (state.fontFamilyMode !== "site") {
      css += `  font-family: ${state.fontStack} !important;\n`;
    }

    if (isPropertyOverride("fontSize")) {
      css += `  font-size: ${Number(state.fontSize)}px !important;\n`;
    }

    if (isPropertyOverride("fontWeight")) {
      css += `  font-weight: ${Number(state.fontWeight)} !important;\n`;
    }

    if (isPropertyOverride("lineHeight")) {
      css += `  line-height: ${Number(state.lineHeight)} !important;\n`;
    }

    if (isPropertyOverride("letterSpacing")) {
      css += `  letter-spacing: ${Number(state.letterSpacing)}px !important;\n`;
    }

    if (isPropertyOverride("wordSpacing")) {
      css += `  word-spacing: ${Number(state.wordSpacing)}px !important;\n`;
    }

    if (isPropertyOverride("textTransform")) {
      css += `  text-transform: ${state.textTransform} !important;\n`;
    }

    if (isPropertyOverride("fontStyle")) {
      css += `  font-style: ${state.fontStyle} !important;\n`;
    }

    if (isPropertyOverride("textDecoration")) {
      css += `  text-decoration-line: ${state.textDecoration} !important;\n`;
    }

    css += `}\n`;

    if (state.useHeadingFont && state.fontFamilyMode !== "site") {
      css += `\n/* Separate heading font */\nh1, h2, h3, h4, h5, h6 {\n`;
      css += `  font-family: ${state.headingFontStack} !important;\n`;

      if (isPropertyOverride("fontWeight")) {
        css += `  font-weight: ${Number(state.headingWeight)} !important;\n`;
      }

      css += `}\n`;
    }

    $("cssOutput").value = css;
  };

  const saveState = async () => {
    await chrome.storage.local.set({
      typographyLabState: state,
      typographyLabPresets: presets,
      typographyLabGoogleApiKey: googleApiKey
    });
  };

  const renderPresets = () => {
    const list = $("presetList");
    list.innerHTML = "";

    if (!presets.length) {
      const empty = document.createElement("div");
      empty.className = "selected-element empty";
      empty.textContent = "No saved presets yet.";
      list.appendChild(empty);
      return;
    }

    presets.forEach((preset) => {
      const row = document.createElement("div");
      row.className = "preset-item";

      const info = document.createElement("div");
      const title = document.createElement("strong");
      title.textContent = preset.name;

      const meta = document.createElement("span");
      meta.textContent =
        `${preset.state.fontFamily} · ${preset.state.fontSize}px · ${preset.state.fontWeight} · ${Number(preset.state.lineHeight).toFixed(2)} line`;

      info.append(title, meta);

      const actions = document.createElement("div");
      actions.className = "preset-actions";

      const load = document.createElement("button");
      load.type = "button";
      load.textContent = "Load";
      load.addEventListener("click", async () => {
        state = normalizeState(preset.state);
        ensurePropertyModes();
        updateControls();

        if (state.fontFamily) {
          await loadGoogleFontCss(state.fontFamily);
        }

        await applyPreview();
        showToast(`Loaded ${preset.name}`);
      });

      const deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.textContent = "Delete";
      deleteButton.addEventListener("click", async () => {
        presets = presets.filter((item) => item.id !== preset.id);
        await saveState();
        renderPresets();
      });

      actions.append(load, deleteButton);
      row.append(info, actions);
      list.appendChild(row);
    });
  };

  const savePreset = async () => {
    const name = $("presetName").value.trim() ||
      `Preset ${presets.length + 1}`;

    presets.unshift({
      id: crypto.randomUUID(),
      name,
      state: JSON.parse(JSON.stringify(state))
    });

    presets = presets.slice(0, 50);

    $("presetName").value = "";
    await saveState();
    renderPresets();

    showToast("Preset saved.");
  };

  const renderDetectedFonts = (fonts) => {
    const container = $("detectedFonts");
    container.innerHTML = "";

    if (!Array.isArray(fonts) || !fonts.length) {
      container.classList.add("empty");
      container.textContent = "No font data found.";
      return;
    }

    container.classList.remove("empty");

    fonts.forEach((fontInfo) => {
      const row = document.createElement("div");
      row.className = "detected-font";

      const info = document.createElement("div");
      const name = document.createElement("strong");
      name.textContent = fontInfo.family;
      name.style.fontFamily = fontStackFor(fontInfo.family);

      const meta = document.createElement("span");
      meta.textContent =
        `${fontInfo.count} sampled element${fontInfo.count === 1 ? "" : "s"}`;

      info.append(name, meta);

      const preview = document.createElement("button");
      preview.type = "button";
      preview.textContent = "Preview";
      preview.addEventListener("click", () => {
        setFont(fontInfo.family).then(() =>
          showToast(`Previewing ${fontInfo.family}`)
        ).catch(() => {});
      });

      row.append(info, preview);
      container.appendChild(row);
    });
  };

  const detectFonts = async () => {
    try {
      const result = await sendToPage({
        type: "TYPOGRAPHY_LAB_FONT_REPORT"
      });

      if (result?.ok) {
        renderDetectedFonts(result.fonts);
      }
    } catch (error) {
      $("detectedFonts").classList.add("empty");
      $("detectedFonts").textContent =
        error.message || "Unable to detect page fonts.";
    }
  };

  const normalizeCatalog = (payload) => {
    let list = [];

    if (Array.isArray(payload)) {
      list = payload;
    } else if (Array.isArray(payload?.fonts)) {
      list = payload.fonts;
    } else if (Array.isArray(payload?.items)) {
      list = payload.items.map((item) => {
        if (typeof item === "string") return item;
        return item.family || "";
      });
    }

    return Array.from(
      new Set(
        list
          .map((item) => String(item || "").trim())
          .filter(Boolean)
      )
    ).sort((a, b) => a.localeCompare(b));
  };

  const fetchPublicCatalog = async () => {
    const urls = [
      "https://cdn.jsdelivr.net/gh/hasinhayder/google-fonts/fonts.json",
      "https://cdn.jsdelivr.net/gh/hasinhayder/google-fonts@main/fonts.json"
    ];

    let lastError = null;

    for (const url of urls) {
      try {
        const response = await fetch(url, {
          cache: "no-store"
        });

        if (!response.ok) {
          throw new Error(`Catalog HTTP ${response.status}`);
        }

        const payload = await response.json();
        const list = normalizeCatalog(payload);

        if (list.length > 100) {
          return {
            list,
            source: "Public Google Fonts catalog index"
          };
        }
      } catch (error) {
        lastError = error;
      }
    }

    throw lastError || new Error("Unable to load Google Fonts catalog.");
  };

  const fetchOfficialCatalog = async (apiKey) => {
    const endpoint =
      `https://www.googleapis.com/webfonts/v1/webfonts?sort=popularity&key=${encodeURIComponent(apiKey)}`;

    const response = await fetch(endpoint, {
      cache: "no-store"
    });

    if (!response.ok) {
      throw new Error(
        `Google Fonts API HTTP ${response.status}. Check your API key.`
      );
    }

    const payload = await response.json();
    const list = normalizeCatalog(payload);

    if (!list.length) {
      throw new Error("Google Fonts API returned no families.");
    }

    return {
      list,
      source: "Official Google Fonts Developer API"
    };
  };

  const loadFontCatalog = async (force = false) => {
    const sequence = ++refreshSequence;

    $("fontStatus").innerHTML =
      `<span class="loader"></span> Loading Google Fonts catalog…`;

    if (!force) {
      try {
        const saved = await chrome.storage.local.get([
          "typographyLabFonts",
          "typographyLabFontsSource",
          "typographyLabFontsUpdated"
        ]);

        if (Array.isArray(saved.typographyLabFonts) &&
            saved.typographyLabFonts.length > 100) {
              fontCatalog = saved.typographyLabFonts;
          catalogLoadedFrom =
            saved.typographyLabFontsSource || "Cached catalog";
          fontListDisplayLimit = 250;

          renderFontLists();

          $("fontStatus").textContent =
            `${fontCatalog.length.toLocaleString()} fonts · ${catalogLoadedFrom}`;

          // Refresh in the background after using the cache.
          setTimeout(() => {
            loadFontCatalog(true).catch(() => {});
          }, 1000);

          return;
        }
      } catch (_) {}
    }

    try {
      const result = googleApiKey
        ? await fetchOfficialCatalog(googleApiKey)
        : await fetchPublicCatalog();

      if (sequence !== refreshSequence) return;

      fontCatalog = result.list;
      catalogLoadedFrom = result.source;
      fontListDisplayLimit = 250;

      await chrome.storage.local.set({
        typographyLabFonts: fontCatalog,
        typographyLabFontsSource: catalogLoadedFrom,
        typographyLabFontsUpdated: Date.now()
      });

      renderFontLists();

      $("fontStatus").textContent =
        `${fontCatalog.length.toLocaleString()} fonts · ${catalogLoadedFrom}`;
    } catch (error) {
      fontCatalog = Array.from(new Set(BUILTIN_FONTS))
        .sort((a, b) => a.localeCompare(b));
      fontListDisplayLimit = 250;

      catalogLoadedFrom = "Built-in fallback list";
      renderFontLists();

      $("fontStatus").textContent =
        `Catalog unavailable — using ${fontCatalog.length} fallback fonts`;

      showToast("Google Fonts catalog could not be refreshed.");
    }
  };

  const filteredFonts = (query, limit = 80) => {
    const needle = String(query || "").trim().toLowerCase();

    const source = needle
      ? fontCatalog.filter((name) => name.toLowerCase().includes(needle))
      : fontCatalog;

    return source.slice(0, limit);
  };

  const renderFontOption = (family, selected) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "font-option";
    button.classList.toggle("active", selected === family);
    button.dataset.font = family;

    const left = document.createElement("div");
    const name = document.createElement("div");
    name.className = "font-name";
    name.textContent = family;
    name.style.fontFamily = fontStackFor(family);

    const category = document.createElement("div");
    category.className = "font-category";
    category.textContent = "Google Font";

    left.append(name, category);

    const arrow = document.createElement("div");
    arrow.className = "font-arrow";
    arrow.textContent = "›";

    button.append(left, arrow);

    button.addEventListener("click", () => {
      setFont(family).then(() => {
        showToast(`Previewing ${family}`);
      }).catch((error) => {
        showToast(error.message || "Font preview failed.");
      });
    });

    return button;
  };

  const getSortedCatalog = () => {
    const query = $("fontSearch").value.trim().toLowerCase();

    let fonts = query
      ? fontCatalog.filter((family) =>
          family.toLowerCase().includes(query)
        )
      : [...fontCatalog];

    if ($("fontSort").value === "alpha") {
      fonts.sort((a, b) => a.localeCompare(b));
    }
    // Popular ordering is preserved when the official API is used. For the
    // public alphabetical index, the list remains alphabetic rather than
    // pretending we have popularity data we do not have.

    return fonts;
  };

  const renderFontLists = () => {
    const list = $("fontList");
    list.innerHTML = "";

    const fonts = getSortedCatalog();
    const total = fonts.length;
    const visible = fonts.slice(0, fontListDisplayLimit);

    if (!visible.length) {
      const empty = document.createElement("div");
      empty.className = "selected-element empty";
      empty.textContent = "No matching fonts.";
      list.appendChild(empty);
    } else {
      visible.forEach((family) => {
        list.appendChild(renderFontOption(family, state.fontFamily));
      });
    }

    const showAll = $("showAllFontsBtn");
    if (!showAll) return;

    if (total > visible.length) {
      showAll.classList.remove("hidden");
      showAll.textContent =
        `Show all ${total.toLocaleString()} fonts`;

      if (fontListDisplayLimit >= total) {
        showAll.classList.add("hidden");
      }
    } else {
      showAll.classList.add("hidden");
    }

    renderHeadingFontList();
  };

  const renderHeadingFontList = () => {
    const list = $("headingFontList");
    list.innerHTML = "";

    const fonts = filteredFonts($("headingFontSearch").value, 45);

    if (!fonts.length) {
      const empty = document.createElement("div");
      empty.className = "selected-element empty";
      empty.textContent = "No matching fonts.";
      list.appendChild(empty);
      return;
    }

    fonts.forEach((family) => {
      const button = renderFontOption(
        family,
        state.headingFontFamily
      );

      button.addEventListener("click", async (event) => {
        event.stopPropagation();

        state.headingFontFamily = family;
        state.headingFontStack = fontStackFor(family);

        await loadGoogleFontCss(family);
        updateControls();
        scheduleApply();
      }, true);

      list.appendChild(button);
    });
  };

  const customFontFormat = (extension) => {
    switch (String(extension).toLowerCase()) {
      case "woff2":
        return {
          mime: "font/woff2",
          format: "woff2"
        };
      case "woff":
        return {
          mime: "font/woff",
          format: "woff"
        };
      case "ttf":
        return {
          mime: "font/ttf",
          format: "truetype"
        };
      case "otf":
        return {
          mime: "font/otf",
          format: "opentype"
        };
      default:
        return null;
    }
  };

  const sanitizeCustomFamily = (fileName) => {
    const withoutExt = String(fileName)
      .replace(/\.[^/.]+$/, "")
      .replace(/[_-]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();

    return withoutExt || "Typography Lab Custom";
  };

  const renderCustomFonts = () => {
    const list = $("customFontList");
    if (!list) return;

    list.innerHTML = "";

    if (!customFonts.length) {
      return;
    }

    customFonts.forEach((font) => {
      const item = document.createElement("div");
      item.className = "custom-font-item";

      const info = document.createElement("div");
      const title = document.createElement("strong");
      title.textContent = font.family;

      const meta = document.createElement("span");
      meta.textContent = `${font.fileName} · ${font.format.toUpperCase()}`;

      info.append(title, meta);

      const useButton = document.createElement("button");
      useButton.type = "button";
      useButton.textContent = "Preview";
      useButton.addEventListener("click", async () => {
        state.fontFamily = font.family;
        state.fontStack =
          `"Typography Lab Custom — ${font.id}", system-ui, sans-serif`;
        state.loadedFontCss = font.css;

        updateControls();
        await injectCustomFontCss();
        await applyPreview();

        showToast(`Previewing ${font.family}`);
      });

      item.append(info, useButton);
      list.appendChild(item);
    });
  };

  const persistCustomFonts = async () => {
    // Store metadata and CSS; the CSS contains the font data itself as a
    // data URL, so the custom font remains available in extension storage.
    await chrome.storage.local.set({
      typographyLabCustomFonts: customFonts
    });
  };

  const injectCustomFontCss = async () => true;

  const loadCustomFontFiles = async (fileList) => {
    const files = Array.from(fileList || []);

    if (!files.length) return;

    let loadedCount = 0;

    for (const file of files) {
      const extension =
        String(file.name.split(".").pop() || "").toLowerCase();

      const descriptor = customFontFormat(extension);

      if (!descriptor) {
        showToast(`${file.name}: unsupported font format.`);
        continue;
      }

      if (file.size > 25 * 1024 * 1024) {
        showToast(`${file.name}: file is larger than 25 MB.`);
        continue;
      }

      try {
        const buffer = await file.arrayBuffer();
        const family = sanitizeCustomFamily(file.name);
        const uniqueFamily =
          `${family} ${Math.abs(hashString(file.name + file.size))}`;

        const face = {
          family: `Typography Lab Custom — ${uniqueFamily}`,
          style: "normal",
          // A variable font can use this range. A static font will still
          // load and the browser can synthesize other weights.
          weight: "100 900",
          stretch: "normal",
          unicodeRange: "",
          base64: arrayBufferToBase64(buffer)
        };

        const result = await sendToPage({
          type: "TYPOGRAPHY_LAB_LOAD_CUSTOM_FONT",
          face
        });

        if (!result?.ok) {
          throw new Error(
            result?.result?.error ||
            "The browser rejected the font."
          );
        }

        const record = {
          id: crypto.randomUUID(),
          family,
          uniqueFamily: face.family,
          fileName: file.name,
          format: extension,
          size: file.size,
          face,
          createdAt: Date.now()
        };

        const existingIndex = customFonts.findIndex(
          (item) =>
            item.fileName === record.fileName &&
            item.size === record.size
        );

        if (existingIndex >= 0) {
          customFonts[existingIndex] = record;
        } else {
          customFonts.unshift(record);
        }

        state.fontFamily = family;
        state.fontStack =
          `"${face.family}", system-ui, sans-serif`;
        state.fontFamilyMode = "override";
        state.loadedFontCss = "";

        loadedCount += 1;
      } catch (error) {
        showToast(
          `${file.name}: ${error.message || "could not be loaded"}`
        );
      }
    }

    await persistCustomFonts();
    renderCustomFonts();

    if (loadedCount) {
      updateControls();
      await applyPreview();

      setFontLoadStatus(
        `${loadedCount} custom font${loadedCount === 1 ? "" : "s"} loaded successfully.`,
        "success"
      );
    }
  };

  // Small deterministic hash used only to distinguish same-named local files.
  const hashString = (value) => {
    let hash = 2166136261;

    for (let i = 0; i < value.length; i++) {
      hash ^= value.charCodeAt(i);
      hash +=
        (hash << 1) +
        (hash << 4) +
        (hash << 7) +
        (hash << 8) +
        (hash << 24);
    }

    return hash | 0;
  };

  const saveOfficialApiKey = async () => {
    googleApiKey = $("officialApiKey").value.trim();

    if (!googleApiKey) {
      showToast("Enter a Google API key first.");
      return;
    }

    await chrome.storage.local.set({
      typographyLabGoogleApiKey: googleApiKey
    });

    showToast("API key saved locally. Refreshing catalog…");
    await loadFontCatalog(true);
  };

  const setTarget = (target) => {
    state.target = target;
    updateControls();
    scheduleApply();
  };

  const setupEvents = () => {
    $("refreshBtn").addEventListener("click", async () => {
      try {
        await refreshPage();
        await detectFonts();
      } catch (_) {}
    });

    document.querySelectorAll(".target-button").forEach((button) => {
      button.addEventListener("click", () => {
        setTarget(button.dataset.target);
      });
    });

    document.querySelectorAll(".mode-row[data-property]").forEach((row) => {
      const property = row.dataset.property;

      row.querySelectorAll('input[type="radio"]').forEach((radio) => {
        radio.addEventListener("change", () => {
          if (radio.checked) {
            setPropertyMode(property, radio.value);
          }
        });
      });
    });

    $("fontOnlyBtn").addEventListener("click", setFontFamilyOnlyMode);

    $("customSelector").addEventListener("input", () => {
      state.selector = $("customSelector").value;
      scheduleApply();
    });

    $("inspectBtn").addEventListener("click", async () => {
      try {
        state.target = "custom";
        updateControls();

        await sendToPage({
          type: "TYPOGRAPHY_LAB_START_PICKER"
        });

        showToast("Click the visible element on the webpage.");
      } catch (error) {
        showToast(error.message || "Could not start page inspector.");
      }
    });

    $("preserveIcons").addEventListener("change", () => {
      state.preserveIcons = $("preserveIcons").checked;
      scheduleApply();
    });

    $("fontSearch").addEventListener("input", () => {
      // Search results intentionally expand to every matching font instead
      // of being capped at the normal browse limit.
      fontListDisplayLimit = 10000;
      renderFontLists();
    });

    $("showAllFontsBtn").addEventListener("click", () => {
      fontListDisplayLimit = 10000;
      renderFontLists();
      showToast(`Showing all ${fontCatalog.length.toLocaleString()} fonts.`);
    });

    $("fontSort").addEventListener("change", renderFontLists);

    // The primary sort listener above handles redraws.

    $("headingFontSearch").addEventListener("input", renderHeadingFontList);

    $("refreshFontsBtn").addEventListener("click", () => {
      loadFontCatalog(true).catch(() => {});
    });

    $("detectFontsBtn").addEventListener("click", detectFonts);

    $("originalSiteFontBtn").addEventListener("click", () => {
      setFontFamilyMode(
        state.fontFamilyMode === "site" ? "override" : "site"
      );

      showToast(
        state.fontFamilyMode === "site"
          ? "Original site font enabled."
          : `Previewing ${state.fontFamily}.`
      );
    });

    $("extensionEnabled").addEventListener("change", () => {
      setExtensionEnabled(
        $("extensionEnabled").checked
      ).catch((error) => {
        showToast(error.message || "Could not change extension state.");
        $("extensionEnabled").checked = state.enabled;
        updateExtensionUi();
      });
    });

    $("fontFallback").addEventListener("input", () => {
      const fallback =
        $("fontFallback").value.trim() || "system-ui, sans-serif";

      state.fontStack = `"${state.fontFamily}", ${fallback}`;
      updateFontPreview();
      scheduleApply();
    });

    $("officialApiKey").addEventListener("change", () => {
      googleApiKey = $("officialApiKey").value.trim();
    });

    $("saveApiKeyBtn").addEventListener("click", () => {
      saveOfficialApiKey().catch((error) => {
        showToast(error.message || "Could not save API key.");
      });
    });

    $("customFontFiles").addEventListener("change", () => {
      loadCustomFontFiles($("customFontFiles").files).catch((error) => {
        showToast(error.message || "Could not load custom font.");
      });

      // Clear the input so the same filename can be selected again later.
      $("customFontFiles").value = "";
    });

    $("fontSize").addEventListener("input", () => {
      state.fontSize = Number($("fontSize").value);
      updateOutputs();
      updateFontPreview();
      scheduleApply();
    });

    $("fontWeight").addEventListener("change", () => {
      state.fontWeight = Number($("fontWeight").value);
      updateFontPreview();
      scheduleApply();
    });

    $("lineHeight").addEventListener("input", () => {
      state.lineHeight = Number($("lineHeight").value);
      updateOutputs();
      updateFontPreview();
      scheduleApply();
    });

    $("letterSpacing").addEventListener("input", () => {
      state.letterSpacing = Number($("letterSpacing").value);
      updateOutputs();
      updateFontPreview();
      scheduleApply();
    });

    $("wordSpacing").addEventListener("input", () => {
      state.wordSpacing = Number($("wordSpacing").value);
      updateOutputs();
      scheduleApply();
    });

    $("textTransform").addEventListener("change", () => {
      state.textTransform = $("textTransform").value;
      scheduleApply();
    });

    $("fontStyle").addEventListener("change", () => {
      state.fontStyle = $("fontStyle").value;
      scheduleApply();
    });

    $("textDecoration").addEventListener("change", () => {
      state.textDecoration = $("textDecoration").value;
      scheduleApply();
    });

    $("useHeadingFont").addEventListener("change", () => {
      state.useHeadingFont = $("useHeadingFont").checked;
      updateControls();
      renderHeadingFontList();
      scheduleApply();
    });

    $("headingWeight").addEventListener("change", () => {
      state.headingWeight = Number($("headingWeight").value);
      scheduleApply();
    });

    $("headingScale").addEventListener("input", () => {
      state.headingSizeScale = Number($("headingScale").value);
      updateOutputs();
      scheduleApply();
    });

    $("clearSelectionBtn").addEventListener("click", async () => {
      try {
        await sendToPage({
          type: "TYPOGRAPHY_LAB_CLEAR_SELECTION"
        });
      } catch (_) {}

      selectedInfo = null;
      state.selector = "";
      $("customSelector").value = "";
      updateSelectedElement(null);
      renderApplicationState(null);
      updateControls();
    });

    $("applyBtn").addEventListener("click", () => {
      applyPreview()
        .then(() => showToast("Preview applied."))
        .catch((error) => showToast(error.message || "Preview failed."));
    });

    $("resetBtn").addEventListener("click", async () => {
      try {
        await sendToPage({
          type: "TYPOGRAPHY_LAB_RESET"
        });

        if (lastInjectedFontCss && currentTabId) {
          try {
            await chrome.scripting.removeCSS({
              target: { tabId: currentTabId },
              css: lastInjectedFontCss
            });
          } catch (_) {}
        }

        lastInjectedFontCss = "";

        if (lastCustomFontCss && currentTabId) {
          try {
            await chrome.scripting.removeCSS({
              target: { tabId: currentTabId },
              css: lastCustomFontCss
            });
          } catch (_) {}
        }

        lastCustomFontCss = "";
        state.enabled = false;

        await saveState();
        showToast("Preview reset.");
      } catch (error) {
        showToast(error.message || "Could not reset page.");
      }
    });

    $("savePresetBtn").addEventListener("click", () => {
      savePreset().catch((error) =>
        showToast(error.message || "Could not save preset.")
      );
    });

    $("copyCssBtn").addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText($("cssOutput").value);
        showToast("CSS copied.");
      } catch (_) {
        $("cssOutput").focus();
        $("cssOutput").select();
        document.execCommand("copy");
        showToast("CSS copied.");
      }
    });

    $("downloadCssBtn").addEventListener("click", () => {
      const blob = new Blob(
        [$("cssOutput").value || updateExport()],
        { type: "text/css;charset=utf-8" }
      );

      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = "typography-lab-v3.css";
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(url);
      showToast("CSS file generated.");
    });

    chrome.runtime.onMessage.addListener((message) => {
      if (message?.type === "TYPOGRAPHY_LAB_ELEMENT_SELECTED") {
        const info = message.info;
        updateSelectedElement(info);
        renderApplicationState(null);

        state.target = "custom";
        state.selector = info?.selector || "";
        updateControls();

        showToast("Element selected.");
        scheduleApply();
      }
    });

    chrome.tabs.onActivated.addListener(async () => {
      lastUserTypographyCss = "";

      try {
        await refreshPage();
        await detectFonts();

        // Reapply the saved preview to the newly active page.
        if (state.enabled) {
          await applyPreview();
        }
      } catch (_) {}
    });

    chrome.tabs.onUpdated.addListener(async (_tabId, changeInfo) => {
      if (changeInfo.status !== "complete") return;

      lastUserTypographyCss = "";

      try {
        await refreshPage();
        await detectFonts();

        if (state.enabled) {
          if (
            state.loadedFontCss &&
            state.fontStack.includes("Typography Lab Custom")
          ) {
            await injectCustomFontCss();
          } else if (
            state.fontFamily &&
            state.fontFamilyMode !== "site"
          ) {
            await loadGoogleFontCss(state.fontFamily);
          }

          await applyPreview();
        }
      } catch (_) {}
    });
  };

  const init = async () => {
    const saved = await chrome.storage.local.get([
      "typographyLabState",
      "typographyLabPresets",
      "typographyLabGoogleApiKey"
    ]);

    state = normalizeState(saved.typographyLabState);
    ensurePropertyModes();

    if (typeof state.enabled !== "boolean") {
      state.enabled = true;
    }

    presets = Array.isArray(saved.typographyLabPresets)
      ? saved.typographyLabPresets.map((preset) => ({
          ...preset,
          state: normalizeState(preset.state)
        }))
      : [];
    googleApiKey = String(saved.typographyLabGoogleApiKey || "");

    customFonts = Array.isArray(saved.typographyLabCustomFonts)
      ? saved.typographyLabCustomFonts
      : [];

    $("officialApiKey").value = googleApiKey;

    setupEvents();
    renderCustomFonts();
    renderPresets();
    updateControls();
    updateSelectedElement(null);

    try {
      const tabs = await getTabs();
      currentTabId = tabs[0]?.id || null;
    } catch (_) {}

    await loadFontCatalog(false);

    try {
      await refreshPage();
      await detectFonts();

      if (state.enabled) {
        await loadGoogleFontCss(state.fontFamily);
        await applyPreview();
      }
    } catch (_) {}
  };

  init().catch((error) => {
    $("pageStatus").textContent = error.message || "Initialization failed.";
  });
})();