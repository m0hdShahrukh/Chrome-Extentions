# Typography Lab v3.5

# Typography Lab v3.3

Typography Lab is a Chrome / Edge Manifest V3 extension for visually previewing typography on live websites without editing the website's actual source, WordPress, Elementor, database or server.

## What v3 fixes

The v2 approach could fail on common nested structures such as:

```html
<h1><span>Example title</span></h1>
```

because CSS applied to `h1` alone can still lose to a more specific `span` rule.

v3 uses an element-aware text-targeting engine:

1. It finds actual text nodes.
2. It identifies the element that renders each text node.
3. It marks those text-rendering elements temporarily.
4. It applies the typography override directly to those elements with `!important`.
5. It repeats the scan when a SPA / React / Next.js page adds or replaces DOM content.
6. It can preserve common icon-font elements so icon glyphs do not accidentally become the selected text font.

This is designed for structures such as:

```html
<h1><span>Example</span></h1>
<h1><span><strong>Example</strong></span></h1>
<a><span>Read More</span></a>
<button><span>Download</span></button>
<div><p><span>Body text</span></p></div>
```

## Targets

- Whole site
- Headings
- Body
- Navigation
- Buttons
- Custom selector

The Whole Site target is not just `h1,h2,p,...`; it walks the rendered text structure so nested wrappers receive the preview.

## Dynamic sites

A `MutationObserver` watches the document while the preview is active.

This means newly inserted content from:

- React
- Next.js
- Vue
- AJAX
- WordPress blocks
- Elementor
- Infinite scroll
- SPA navigation

can be re-targeted automatically.

## Google Fonts catalog

The font picker no longer requires manually typing a family name.

By default the extension loads a public Google Fonts family index, caches it locally, and provides search through the catalog. The public index used by this build is a data-only catalog sourced from the Google Fonts ecosystem and distributed as JSON.

The extension also supports the official Google Fonts Developer API.

Google's official documentation states that the Developer API provides metadata for all families served by Google Fonts and requires an API key for requests.

To use the official API:

1. Open the extension.
2. Put your Google Fonts API key into `Optional Google API key`.
3. Click `Use official Google Fonts API`.
4. The catalog will refresh using Google's official API.

Without a key, use the built-in public catalog path.

## Font loading

Selecting a family automatically requests its Google Fonts CSS and injects it into the active page for preview.

You can search and click:

```text
Inter
Manrope
Poppins
Figtree
Space Grotesk
Geist
Plus Jakarta Sans
...
```

rather than typing a family name.

The extension requests the actual Google Fonts CSS, so the selected font is really rendered when the browser can access the Google Fonts service.

## Existing font detection

The Page Fonts section scans rendered text and the browser's `document.fonts` collection.

It reports the family names found in the live page and lets you click `Preview`.

This is useful for comparing:

```text
Current website font
vs
Inter
vs
Manrope
vs
Poppins
```

## Font controls

- Family
- Font size
- Weight
- Line height
- Letter spacing
- Word spacing
- Text transform
- Font style
- Text decoration

Optional heading system:

- Separate heading font
- Heading weight
- Heading scale

## Inspector

Click:

```text
Custom
→ Pick on page
```

Then click visible text on the webpage.

The extension returns:

- HTML tag
- ID
- classes
- visible text
- computed font
- font size
- weight
- line height
- letter spacing
- generated CSS selector

The selector becomes the Custom target.

## Presets

Save up to 50 typography combinations.

Example:

```text
01 — Inter Modern
02 — Manrope Corporate
03 — Poppins Friendly
```

Load them with one click to compare visual directions.

## CSS export

The extension generates CSS for the chosen target.

Buttons:

- Copy CSS
- Download .css

This is for implementation after you decide which preview is best.

## Browser-only behavior

Typography Lab does not modify:

- WordPress files
- Elementor settings
- React source code
- HTML files on the server
- theme files
- database
- PHP
- server configuration

The page preview exists only in the browser session.

## Installation — Chrome

1. Remove the previous Typography Lab version.
2. Extract `typography-lab-v3.zip`.
3. Open `chrome://extensions/`.
4. Turn on Developer mode.
5. Click `Load unpacked`.
6. Select the extracted `typography-lab` folder.
7. Open `Typography Lab > Details`.
8. Under Site access, choose `On all sites` when available.
9. Reload the website you want to test.
10. Open Typography Lab from the browser toolbar.

## Installation — Edge

1. Remove the previous Typography Lab version.
2. Extract `typography-lab-v3.zip`.
3. Open `edge://extensions/`.
4. Turn on Developer mode.
5. Click `Load unpacked`.
6. Select the `typography-lab` folder.
7. Give it site access.
8. Reload your website.

## Testing the nested-span bug

Use the included `demo.html`.

Open it in a browser using a local web server or a normal HTTP URL.

Test:

```html
<h1>Typography Lab <span>Demo</span></h1>
```

Then use:

```text
Target → Headings
Font → Manrope
Size → 52
Weight → 700
Line Height → 1.05
```

The visible words inside nested spans should change together.

Also test:

```html
<button><span>Example button</span></button>
```

with:

```text
Target → Buttons
```

## Known browser restrictions

No ordinary extension can modify certain protected browser pages, including browser internal pages such as:

```text
chrome://...
edge://...
```

Some cross-origin iframes and closed Shadow DOM trees are also intentionally isolated by browser security.

The extension can work on normal:

- WordPress
- Elementor
- WooCommerce
- HTML/CSS
- PHP
- React
- Next.js
- Vue
- Shopify
- Laravel
- static sites

## Recommended future upgrades

Potential v4/v5 features:

- A/B typography comparison
- 3-column font comparison
- desktop/tablet/mobile preview
- screenshot export
- typography report for a page
- detect heading/body/UI type scales
- font pairing recommendations
- accessibility contrast checks
- export Elementor-ready CSS
- export a complete typography design system
- shadow DOM support
- iframe-aware targeting
- undo/redo history


## v3.1 — Per-property site/custom typography

Every typography property now has two radio controls:

**Use site** — Typography Lab does not inject that CSS property, so the live website keeps its original value.

**Override** — Typography Lab injects your custom value for that property.

Available independently for:

- Font size
- Font weight
- Line height
- Letter spacing
- Word spacing
- Text transform
- Font style
- Text decoration

Font family remains the primary preview control.

### Font family only

The **Font family only** shortcut changes all typography properties to `Use site`.

Example:

```text
Font family      → Manrope
Font size        → Use site
Font weight      → Use site
Line height      → Use site
Letter spacing   → Use site
Word spacing     → Use site
Text transform   → Use site
Font style       → Use site
Text decoration  → Use site
```

This is the recommended mode when you want to answer:

> "How would the website look if I changed only its font family?"

The original website's typography values are preserved individually instead of being replaced by generic extension defaults.

The selected modes are saved inside presets and are respected by CSS export.


## v3.2 — Full font browser + custom font upload

### Browse the complete Google Fonts catalog

The font picker now loads the complete cached Google Fonts family list into the extension.

The normal browsing view shows the first batch for speed. Click:

`Show all N fonts`

to display the complete available catalog.

Typing in the search field automatically removes the browsing limit and searches the full catalog.

### Custom fonts

Use:

`Custom font upload`

Supported formats:

- `.ttf` — TrueType
- `.otf` — OpenType
- `.woff` — Web Open Font Format
- `.woff2` — Web Open Font Format 2

Multiple files can be selected at once.

Each uploaded file is converted to an in-memory/data URL font face and can be previewed without installing the font.

Custom font records are stored locally in extension storage so they can be used again during the browser session. The actual website is not modified.

A custom font is loaded as a separate family such as:

```text
Typography Lab Custom — My Brand Font
```

The original file name is shown in the Custom font list.

### Practical use

For example, upload:

```text
Brand-Regular.woff2
Brand-Bold.ttf
Brand-Display.otf
```

Then preview each file against the same website.

For one family with multiple weights, it is currently best to upload each weight as a separate file and compare them. A future version can add explicit custom-font family/weight grouping and variable-font axis controls.


## v3.3 — Original Site Font + Extension On/Off

### Original Site Font

The Font family section now has an **Original site font** button.

It toggles only the font-family override:

- **Original site font** enabled → the website's original `font-family` is preserved.
- **Original site font** disabled → your selected Typography Lab family is applied again.

The selected preview family is not forgotten, so you can switch:

`Manrope → Original site font → Manrope`

without searching for Manrope again.

This control is independent from the other property modes.

### Extension On / Off

The footer now has an **Extension on / Extension off** control beside Reset.

When the extension is turned **off**:

- all injected typography styles are removed
- injected custom font styles are removed
- the live page returns to its original appearance

When it is turned **on**:

- the current Typography Lab configuration is applied again

This is useful for a direct visual comparison:

`Extension ON → preview font`

vs.

`Extension OFF → original website`

The selected font and saved settings remain stored while the extension is off.

### Important difference

- **Original site font** = only the font family returns to the site's original value; other enabled typography overrides can remain.
- **Extension off** = the complete Typography Lab preview is removed.

### Presets

The extension on/off state and original-site-font mode are retained in saved presets.


## v3.4 — Google Fonts loading reliability

v3.4 fixes a major issue where a font could appear in the catalog/search but fail to render.

The Google Fonts URL is now constructed with `URLSearchParams`, so multi-word families such as:

- Rethink Sans
- Hedvig Letters
- Hedvig Letters Serif
- Familjen Grotesk
- Plus Jakarta Sans
- Space Grotesk
- IBM Plex Sans

are requested using the correct CSS2 family query format.

The extension also no longer depends solely on the target site's ability to load an external Google Fonts stylesheet.

It now:

1. Fetches the Google Fonts CSS in extension context.
2. Parses the returned `@font-face` records.
3. Downloads the actual font files from the Google Fonts CDN.
4. Sends the font binaries to the content script.
5. Registers them with the browser `FontFace` API and `document.fonts`.
6. Verifies that at least one face registered successfully.
7. Shows a visible font-load status instead of silently falling back.

Custom TTF/OTF/WOFF/WOFF2 uploads use the same FontFace registration path.

### Font loading status

The Font family section now displays status such as:

```text
Loading Rethink Sans from Google Fonts…
```

or:

```text
Rethink Sans loaded successfully · 2 font faces
```

or:

```text
Could not load Rethink Sans: ...
```

This makes failures diagnosable.

### Important browser limitation

The extension still cannot modify browser-internal pages such as `chrome://...` or other protected browser surfaces.


## v3.5 — High-priority Elementor/WordPress override

Some page CSS can still beat ordinary injected author CSS, especially highly specific Elementor rules, late-injected stylesheets, or author `!important` declarations.

v3.5 keeps the existing text-node targeting engine and adds a second layer using Chrome's `chrome.scripting.insertCSS()` with `origin: "USER"`.

The runtime is now:

1. Find the actual element rendering the text.
2. Add temporary Typography Lab markers.
3. Generate the preview CSS.
4. Apply it through the content script as the existing fallback.
5. Apply the same CSS through USER-origin CSS.
6. Keep the USER-origin rules active while dynamic page content changes.
7. Remove them on Reset or Extension Off.

The selected-element panel also shows the computed font values after the preview is applied.
